
# climate_modeling_project.py

# === Climate Change Modeling Project ===
# Includes:
# - Sentiment Analysis on NASA Facebook Comments
# - Climate Data Forecasting using Machine Learning

# === Libraries ===
import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# === Part 1: Sentiment Analysis ===
def clean_text(text):
    text = re.sub(r"http\S+", "", text)
    text = re.sub(r"[^A-Za-z\s]", "", text)
    return text.lower()

def sentiment_analysis(filepath):
    df = pd.read_csv(filepath)
    df['clean_text'] = df['Text'].astype(str).apply(clean_text)
    df['polarity'] = df['clean_text'].apply(lambda x: TextBlob(x).sentiment.polarity)
    df['sentiment'] = df['polarity'].apply(lambda x: 'positive' if x > 0 else ('negative' if x < 0 else 'neutral'))

    # Plotting sentiment distribution
    plt.figure(figsize=(8, 5))
    sns.countplot(data=df, x='sentiment', palette='coolwarm')
    plt.title('Sentiment Distribution on NASA Climate Comments')
    plt.savefig('sentiment_distribution.png')
    plt.show()
    return df

# === Part 2: Climate Data Forecasting ===
def load_climate_data(filepath):
    return pd.read_csv(filepath)

def preprocess_climate_data(df, target_col):
    X = df.drop(columns=[target_col])
    y = df[target_col]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled, y, scaler

def train_forecasting_model(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # Evaluation
    print("Model Evaluation:")
    print(f"MAE: {mean_absolute_error(y_test, y_pred):.4f}")
    print(f"MSE: {mean_squared_error(y_test, y_pred):.4f}")
    print(f"R2 Score: {r2_score(y_test, y_pred):.4f}")

    # Plotting results
    plt.figure(figsize=(10, 6))
    plt.scatter(y_test, y_pred, alpha=0.6, color='blue')
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title("Actual vs Predicted Climate Target")
    plt.savefig('forecasting_results.png')
    plt.show()
    return model

def predict_future(model, scaler, future_data_path):
    future_data = pd.read_csv(future_data_path)
    future_data_scaled = scaler.transform(future_data)
    future_predictions = model.predict(future_data_scaled)
    print("Future Predictions:")
    print(future_predictions)
    return future_predictions

# === Main Execution ===
if __name__ == '__main__':
    # Part 1: Sentiment Analysis
    print("\n=== Running Sentiment Analysis ===")
    sentiment_df = sentiment_analysis('datasets/nasa_facebook_comments.csv')

    # Part 2: Climate Forecasting
    print("\n=== Running Climate Forecasting ===")
    climate_df = load_climate_data('datasets/climate_data.csv')
    X, y, scaler = preprocess_climate_data(climate_df, target_col='temperature_anomaly')
    model = train_forecasting_model(X, y)

    # Predict Future (Optional)
    print("\n=== Predicting Future Climate Trends ===")
    predict_future(model, scaler, 'datasets/future_climate_data.csv')
